We fulfilled all the requirements except one that Ole said we could leave for the follow up assignement because it did not make sense to implement it in our project right now.


- For the form, it's not really an error but the JavaScript 
verification on the email is very allowing. 
This choice has been made after doing some research and realising
that a verification that is not allowing enough can cause problem. 
Also, that kind of verification is not enough, so we might as well not overdue it. 
Sending a validation e-mail should be a prefered method


- The application contains several kinds of objects that can be
filtered and work as intended.
However, linking the javaScript filtering to the html tags to remove and add pictures
in accordance to the given price does not work as intended. 
Due to lack of time it has not been fixed.


- The menu object javascript class populates the menu in the HTML file 
with it's sections like "About US" and "Contact".
However, for some reason it seemes to conflict with the CSS file or some other issue 
that is causing the menu items to be shifted to the left of the screen. 
This has not been solved due to lack of time, and also due to the issue being non-critical.